﻿using System;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace test.Models
{
    public class Link
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Original { get; set; }
        public string Project { get; set; }
        public string Active { get; set; }
        public string Correct { get; set; }
        public int Count { get; set; }
    }
}
