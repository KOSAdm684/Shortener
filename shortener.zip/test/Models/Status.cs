﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace test.Models
{
    public class Status
    {
        public string Message { get; set; }
        public string Result { get; set; }
    }
}
