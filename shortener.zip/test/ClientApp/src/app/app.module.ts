import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { HomeComponent } from './home/home.component';
import { CounterComponent } from './counter/counter.component';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import { AddLinkComponent } from './task/addLink.component';
import { AllLinksComponent } from './task/allLinks.component';
import { ActiveLinksComponent } from './task/activeLinks.component';
import { ApiAuthorizationModule } from 'src/api-authorization/api-authorization.module';
import { AuthorizeGuard } from 'src/api-authorization/authorize.guard';
import { AuthorizeInterceptor } from 'src/api-authorization/authorize.interceptor';
import { LinkService } from './task/link.service';
import { ProjectService } from './task/project.service';
import { ProjectsComponent } from './task/projects.component';
import { ProjectComponent } from './task/project.component';

@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent,
    HomeComponent,
    CounterComponent,
    FetchDataComponent,
    AddLinkComponent,
    AllLinksComponent,
    ActiveLinksComponent,
    ProjectsComponent,
    ProjectComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    FormsModule,
    ApiAuthorizationModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent, pathMatch: 'full' },
      { path: 'counter', component: CounterComponent },
      { path: 'addLink', component: AddLinkComponent, canActivate: [AuthorizeGuard] },
      { path: 'activeLinks', component: ActiveLinksComponent, canActivate: [AuthorizeGuard] },
      { path: 'link-data', component: AllLinksComponent, canActivate: [AuthorizeGuard] },
      { path: 'projects', component: ProjectsComponent, canActivate: [AuthorizeGuard] },
      { path: 'fetch-data', component: FetchDataComponent, canActivate: [AuthorizeGuard] },
      { path: 'projects/project/:id', component: ProjectComponent, canActivate: [AuthorizeGuard] }
    ])
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthorizeInterceptor, multi: true },
    LinkService,
    ProjectService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
