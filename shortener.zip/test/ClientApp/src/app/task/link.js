"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Link = /** @class */ (function () {
    function Link(Id, Name, Original, Project, Active, Correct, Count) {
        if (Count === void 0) { Count = 0; }
        this.Id = Id;
        this.Name = Name;
        this.Original = Original;
        this.Project = Project;
        this.Active = Active;
        this.Correct = Correct;
        this.Count = Count;
    }
    return Link;
}());
exports.Link = Link;
//# sourceMappingURL=link.js.map