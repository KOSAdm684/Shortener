export class Project {
  constructor(
    public Id?: string,
    public Name?: string,
    public Count: number = 0) { }
}
