import { Component, OnInit } from '@angular/core';
import { Project } from "./project";
import { ProjectService } from "./project.service";
import { Observable, Subscription } from "rxjs";
import { Router, ActivatedRoute } from '@angular/router';
import { Link } from './link';

@Component({
  selector: 'project',
  templateUrl: './project.component.html'
})
export class ProjectComponent implements OnInit {

  private id: string;
  name: string;
  message: string;
  private lnk: Observable<Link[]>;
  private subscription: Subscription;
  private querySibsctiprion: Subscription;

  constructor(private activatedRoute: ActivatedRoute, private projectService: ProjectService) {

    this.subscription = activatedRoute.params.subscribe(params => this.id = params['id']);
    this.querySibsctiprion = activatedRoute.queryParams.subscribe(
      (queryParam: any) => {
        this.name = queryParam['name'];
      })
  }

  LoadLinks() {
    this.lnk = this.projectService.getLinksOfProject(this.id);
  }

  ngOnInit() {
    this.LoadLinks();
  }
}
