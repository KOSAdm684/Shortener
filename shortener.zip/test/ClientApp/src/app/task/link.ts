export class Link {
  constructor(
    public Id?: string,
    public Name?: string,
    public Original?: string,
    public Project?: string,
    public Active?: number,
    public Correct?: string,
    public Count: number = 0) { }
}
