import { Component, OnInit } from '@angular/core';
import { Project } from "./project";
import { ProjectService } from "./project.service";
import { Observable } from "rxjs";
import { Router } from '@angular/router';
@Component({
  selector: 'app-Projects',
  templateUrl: './projects.component.html'
})
export class ProjectsComponent implements OnInit {
  private prjs: Observable<Project[]>;
  private prj: Project = new Project();
  private view: boolean = true;
  message: String;
  dataSaved = false;

  constructor(private router: Router, private projectService: ProjectService) { }

  LoadProjects() {
    this.prjs = this.projectService.getProjects();
  }

  DeleteProject(id: string) {
    if (confirm("Are You Sure To Delete this Informations")) {
      this.projectService.deleteProject(id).subscribe(
        () => {
          this.dataSaved = true;
          this.message = "Deleted Successfully";
        }
      );
    }
    this.LoadProjects();
  }

  CreateProject() {
    this.projectService.createProject(this.prj).subscribe(
      () => {
        this.message = "Added Successfully";
      }
    );
    this.cancel();
    this.LoadProjects();
  }

  cancel() {
    this.prj = new Project();
    this.view = true;
  }

  add() {
    this.cancel();
    this.view = false;
  }

  ngOnInit() {
    localStorage.clear();
    this.LoadProjects();
  }
}
