import { Component, OnInit } from '@angular/core';
import { LinkService } from './link.service';
import { Link } from './link';
import { Project } from "./project";
import { ProjectService } from "./project.service";
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-addLink',
  templateUrl: './addLink.component.html',
})
export class AddLinkComponent implements OnInit {
  message: string;
  dataSaved = false;
  prjs: Observable<Project[]>;
  addLink: FormGroup;
  LinkIdUpdate = "0";

  constructor(private router: Router, private linkService: LinkService, private projectService: ProjectService) { }

  ngOnInit() {
    this.LoadProjects();
    this.addLink = new FormGroup({
      Name: new FormControl(),
      Original: new FormControl(),
      Project: new FormControl(),
      Active: new FormControl(),
      Correct: new FormControl()
    });
    let Id = localStorage.getItem("Id");
    if (Id != null) {
      this.LinkEdit(Id);
    }
  }

  LoadProjects() {
    this.prjs = this.projectService.getProjects();
  }
  changePrj(e) {
    this.addLink.controls['Project'].setValue(e.target.value, {
      onlySelf: true
    })
  }

  LinkEdit(id: string) {
    this.linkService.getLink(id).subscribe(lnk => {
      this.message = null;
      this.dataSaved = false;
      this.LinkIdUpdate = id;
      this.addLink.controls['Name'].setValue(lnk.Name);
      this.addLink.controls['Original'].setValue(lnk.Original);
      this.addLink.controls['Project'].setValue(lnk.Project);
      this.addLink.controls['Active'].setValue(lnk.Active);
      this.addLink.controls['Correct'].setValue(lnk.Correct);
    });
  }

  InsertLink(link: Link) {
    //if (this.LinkIdUpdate != "0") link.Id = this.LinkIdUpdate;
    link.Id = localStorage.getItem("Id");
    this.linkService.createLink(link).subscribe(
      () => {
        if (this.LinkIdUpdate == "0") {
          this.message = 'Saved Successfully';
        }
        else {
          this.message = 'Update Successfully';
        }
        this.dataSaved = true;
        this.router.navigate(['/link-data']);
      })
  }
  onFormSubmit() {
    const lnk = this.addLink.value;
    this.InsertLink(lnk);
  }
}
