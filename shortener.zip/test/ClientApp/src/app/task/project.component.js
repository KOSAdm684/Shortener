"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ProjectComponent = /** @class */ (function () {
    function ProjectComponent(activatedRoute) {
        this.activatedRoute = activatedRoute;
        this.id = activatedRoute.snapshot.params['id'];
    }
    return ProjectComponent;
}());
exports.ProjectComponent = ProjectComponent;
//# sourceMappingURL=project.component.js.map