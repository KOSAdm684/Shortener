import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Link } from './link';
import { Observable } from 'rxjs';

@Injectable()
export class LinkService {
  private url = "/api/links/";

  constructor(private http: HttpClient) { }

  getLinks(): Observable<Link[]> {
    return this.http.get<Link[]>(this.url + 'GetAllLinks');
  }

  createLink(link: Link) {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post(this.url + 'InsertLink/', link, httpOptions);
  }

  deleteLink(id: string): Observable<number> {
    return this.http.get<number>(this.url + 'DeleteLink/?id=' + id);
  }

  getLink(id: string) {
    return this.http.get<Link>(this.url + 'DetLinkById/?id=' + id);
  }
}
