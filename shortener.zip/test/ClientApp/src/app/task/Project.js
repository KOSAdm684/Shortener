"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Project = /** @class */ (function () {
    function Project(Id, Name, Count) {
        if (Count === void 0) { Count = 0; }
        this.Id = Id;
        this.Name = Name;
        this.Count = Count;
    }
    return Project;
}());
exports.Project = Project;
//# sourceMappingURL=project.js.map