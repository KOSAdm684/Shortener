import { Component, OnInit } from '@angular/core';
import { Link } from "./link";
import { LinkService } from "./link.service";
import { Observable } from "rxjs";
import { Router } from '@angular/router';
@Component({
  selector: 'app-AllLinks',
  templateUrl: './allLinks.component.html'
})
export class AllLinksComponent implements OnInit {
  private lnk: Observable<Link[]>;
  massage: String;
  dataSaved = false;

  constructor(private router: Router, private linkService: LinkService) { }
  LoadLinks() {

    this.lnk = this.linkService.getLinks();
    console.log(this.lnk);
  }
  LinkEdit(id: string) {
    localStorage.removeItem("Id");
    localStorage.setItem("Id", id);
    this.router.navigate(['/addLink'], { queryParams: { Id: id } });
  }
  DeleteLink(id: string) {
    if (confirm("Are You Sure To Delete this Informations")) {
      this.linkService.deleteLink(id).subscribe(
        () => {
          this.dataSaved = true;
          this.massage = "Deleted Successfully";
        }
      );
    }
    this.lnk = this.linkService.getLinks();
  }
  ngOnInit() {
    localStorage.clear();
    this.LoadLinks();
  }
}
