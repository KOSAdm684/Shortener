import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Project } from './project';
import { Link } from './link';
import { Observable } from 'rxjs';

@Injectable()
export class ProjectService {
  private url = "/api/projects/";

  constructor(private http: HttpClient) { }

  getProjects(): Observable<Project[]> {
    console.log(this.http.get<Project[]>(this.url + 'GetAllProjects'));
    return this.http.get<Project[]>(this.url + 'GetAllProjects');
  }

  createProject(project: Project) {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    console.log(project);
    return this.http.post(this.url + 'InsertProject/', project, httpOptions);
  }

  deleteProject(id: string): Observable<number> {
    return this.http.get<number>(this.url + 'DeleteProject/?id=' + id);
  }

  getLinksOfProject(id: string): Observable<Link[]> {
    return this.http.get<Link[]>(this.url + 'GetLinksByProject/?id=' + id);
  }
}
