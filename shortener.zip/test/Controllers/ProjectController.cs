﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDB.Driver;
using test.Models;

namespace test.Controllers
{
    [ApiController]
    [Route("api/projects")]
    public class ProjectController : Controller
    {
        private readonly string conStr = "mongodb://localhost";

        [Route("InsertProject")]
        [HttpPost]
        public object Post(Project objVM)
        {
            try
            {
                var Client = new MongoClient(conStr);
                var DB = Client.GetDatabase("CustomProject");
                var collection = DB.GetCollection<Project>("Projects");

                if (objVM.Id == null || objVM.Id == "")
                {
                    int count = (int)collection.CountDocuments(FilterDefinition<Project>.Empty);
                    if (count == 0)
                    {
                        objVM.Id = "1";
                    }
                    else
                    {
                        var res = collection.Find(x => true).SortByDescending(d => d.Id).Limit(1).FirstOrDefault();
                        int resId = Int32.Parse(res.Id);
                        resId += 1;
                        objVM.Id = resId.ToString();
                    }

                    collection.InsertOne(objVM);
                    return new Status { Result = "Success", Message = "Link Insert Successfully" };
                }
                else
                {
                    var update = collection.FindOneAndUpdateAsync(Builders<Project>.Filter.Eq("Id", objVM.Id),
                                                                  Builders<Project>.Update.Set("Name", objVM.Name)
                                                                                          .Set("Count", objVM.Count));

                    return new Status { Result = "Success", Message = "Link Insert Successfully" };
                }
            }
            catch (Exception ex)
            {
                return new Status { Result = "Error", Message = ex.Message.ToString() };
            }

        }

        [Route("DeleteProject")]
        [HttpGet]
        public object Delete(string id)
        {
            try
            {
                var Client = new MongoClient(conStr);
                var DB = Client.GetDatabase("CustomProject");

                var collection = DB.GetCollection<Project>("Projects");
                var collectionL = DB.GetCollection<Link>("Links");

                var prj = collection.Find(Builders<Project>.Filter.Where(s => s.Id == id)).FirstOrDefault();
                var DeleteLinks = collectionL.DeleteMany(Builders<Link>.Filter.Eq("Project", prj.Name));

                var DeleteObj = collection.DeleteOneAsync(Builders<Project>.Filter.Eq("Id", id));

                return new Status { Result = "Success", Message = "Link Delete Successfully" };
            }
            catch (Exception ex)
            {
                return new Status { Result = "Error", Message = ex.Message.ToString() };
            }
        }

        [Route("GetAllProjects")]
        [HttpGet]
        public object GetProjects()
        {
            var Client = new MongoClient(conStr);
            var DB = Client.GetDatabase("CustomProject");
            var collection = DB.GetCollection<Project>("Projects").Find(new BsonDocument()).ToList();
            return Json(collection);
        }

        [Route("GetLinksByProject")]
        [HttpGet]
        public object GetLinksByProject(string id)
        {
            var Client = new MongoClient(conStr);
            var DB = Client.GetDatabase("CustomProject");
            var collection = DB.GetCollection<Project>("Projects");
            var collectionL = DB.GetCollection<Link>("Links");

            var prj = collection.Find(Builders<Project>.Filter.Where(s => s.Id == id)).FirstOrDefault();
            var links = collectionL.Find(Builders<Link>.Filter.Where(s => s.Project == prj.Name)).ToList();

            return Json(links);
        }
    }
}
