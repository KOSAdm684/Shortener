﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using test.Models;

namespace test.Controllers
{
    [Route("/GetCorrect")]
    public class CorrectController : Controller
    {
        [HttpGet("{id}")]
        public IActionResult GetCorrect(string id)
        {
            var Client = new MongoClient("mongodb://localhost");
            var DB = Client.GetDatabase("CustomProject");

            var collection = DB.GetCollection<Link>("Links");
            var plant = collection.Find(Builders<Link>.Filter.Where(s => s.Id == id)).FirstOrDefault();
            var update = collection.FindOneAndUpdateAsync(Builders<Link>.Filter.Eq("Id", id),
                                                                  Builders<Link>.Update.Set("Count", plant.Count + 1));

            var collectionP = DB.GetCollection<Project>("Projects");
            var plantP = collectionP.Find(Builders<Project>.Filter.Where(s => s.Name == plant.Project)).FirstOrDefault();
            var updateP = collectionP.FindOneAndUpdateAsync(Builders<Project>.Filter.Eq("Name", plant.Project),
                                                                  Builders<Project>.Update.Set("Count", plantP.Count + 1));
            if (plant.Active == "1")
            {
                string correctUrl = plant.Original;
                return Redirect(correctUrl);
            }
            else
            {
                return Redirect("https://localhost:44367");
            }
        }
    }
}
