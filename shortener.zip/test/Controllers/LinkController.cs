﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using MongoDB.Bson;
using test.Models;
using System.Configuration;
using Microsoft.IdentityModel.Protocols;
using IdentityServer4.Models;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Server.HttpSys;
using System.Security.Claims;

namespace test.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/links")]
    public class LinkController : Controller
    {
        private readonly string conStr = "mongodb://localhost";
        [Route("InsertLink")]
        [HttpPost]
        public object Post(Link objVM)
        {
            try
            {
                var Client = new MongoClient(conStr);
                var DB = Client.GetDatabase("CustomProject");
                var collection = DB.GetCollection<Link>("Links");
                
                if (objVM.Id == null || objVM.Id == "")
                {
                    int count = (int)collection.CountDocuments(FilterDefinition<Link>.Empty);
                    if (count == 0)
                    {
                        objVM.Id = "1";
                    }
                    else
                    {
                        var res = collection.Find(x => true).SortByDescending(d => d.Id).Limit(1).FirstOrDefault();
                        int resId = Int32.Parse(res.Id);
                        resId += 1;
                        objVM.Id = resId.ToString();
                    }

                    objVM.Correct = "https://localhost:44367/GetCorrect/" + objVM.Id;
                    objVM.Count = 0;
                    collection.InsertOne(objVM);
                    return new Status { Result = "Success", Message = "Link Insert Successfully" };
                }
                else
                {
                    var update = collection.FindOneAndUpdateAsync(Builders<Link>.Filter.Eq("Id", objVM.Id),
                                                                  Builders<Link>.Update.Set("Name", objVM.Name)
                                                                                       .Set("Original", objVM.Original)
                                                                                       .Set("Project", objVM.Project)
                                                                                       .Set("Active", objVM.Active));
                    return new Status { Result = "Success", Message = "Link Insert Successfully" };
                }
            }
            catch (Exception ex)
            {
                return new Status { Result = "Error", Message = ex.Message.ToString() };
            }
                
        }

        [Route("DeleteLink")]
        [HttpGet]
        public object Delete(string id)
        {
            try
            {
                var Client = new MongoClient(conStr);
                var DB = Client.GetDatabase("CustomProject");
                var collection = DB.GetCollection<Link>("Links");
                var DeleteObj = collection.DeleteOneAsync(Builders<Link>.Filter.Eq("Id", id));

                return new Status { Result = "Success", Message = "Link Delete Successfully" };
            }
            catch (Exception ex)
            {
                return new Status { Result = "Error", Message = ex.Message.ToString() };
            }
        }

        [Route("GetAllLinks")]
        [HttpGet]
        public object GetLinks()
        {
            var Client = new MongoClient(conStr);
            var DB = Client.GetDatabase("CustomProject");
            var collection = DB.GetCollection<Link>("Links").Find(new BsonDocument()).ToList();
            return Json(collection);
        }

        [Route("GetLinkById")]
        [HttpGet]
        public object GetLinkById(string id)
        {
            var Client = new MongoClient(conStr);
            var DB = Client.GetDatabase("CustomProject");
            var collection = DB.GetCollection<Link>("Links");
            var plant = collection.Find(Builders<Link>.Filter.Where(s => s.Id == id)).FirstOrDefault();
            return Json(plant);
        }
    }
}
